<?php

define('THIS_SCRIPT', 'menucp');

include('init.php');

Display('headercp');

?>